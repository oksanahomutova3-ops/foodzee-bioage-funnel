/* eslint-disable */
import React from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { Check } from '../../components/ui/check/Check';
import { Option } from '../../components/ui/check/Option';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import styles from './BioDailySteps.module.scss';

function Page() {
  const answer = useStore((state) => state.answer);
  const setAnswer = useStore((state) => state.setAnswer);
  const { onNext, onPrev, currentIndex } = useNav();

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('bioDailySteps.title')}</p>
        <p className={styles.description}>{t('bioDailySteps.subtitle')}</p>
      </div>
      <div className={styles.controls}>
        <Check
          defaultValue={answer}
          onChange={(value) => {
            setAnswer(value);
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
              page: 'bioDailySteps',
              answer: value,
            });
            onNext();
          }}
        >
          <Option value="under2k">
            <span>🐌</span> {t('bioDailySteps.options.under2k')}
          </Option>
          <Option value="2kTo5k">
            <span>🚶</span> {t('bioDailySteps.options.twoToFive')}
          </Option>
          <Option value="5kTo8k">
            <span>🏃</span> {t('bioDailySteps.options.fiveToEight')}
          </Option>
          <Option value="8kTo12k">
            <span>⚡</span> {t('bioDailySteps.options.eightToTwelve')}
          </Option>
          <Option value="over12k">
            <span>🏅</span> {t('bioDailySteps.options.overTwelve')}
          </Option>
        </Check>
      </div>
    </div>
  );
}

export default Page;
