/* eslint-disable */
import React, { useState } from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './BioPaywall.module.scss';

function Page() {
  const { currentIndex } = useNav();
  const [plan, setPlan] = useState('trial');

  const handleStart = () => {
    Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
      page: 'bioPaywall',
      plan: plan,
    });
  };

  return (
    <div className={styles.page}>
      {/* Hero */}
      <p className={styles.title}>
        {t('bioPaywall.titleBefore')}
        <span className={styles.titleHighlight}>{t('bioPaywall.titleHighlight')}</span>
        {t('bioPaywall.titleAfter')}
      </p>

      {/* Personal Health Dashboard */}
      <div className={styles.dashboard}>
        <div className={styles.dashboardPhoto} />
        <div className={styles.dashboardData}>
          <p className={styles.dashboardTitle}>{t('bioPaywall.dashboard.title')}</p>
          <div className={styles.dashboardItem}>
            <p className={styles.dashboardLabel}>{t('bioPaywall.dashboard.bioAge')}</p>
            <p className={styles.dashboardValue}>{t('bioPaywall.dashboard.bioAgeValue')}</p>
          </div>
          <div className={styles.dashboardItem}>
            <p className={styles.dashboardLabel}>{t('bioPaywall.dashboard.cellularHealth')}</p>
            <p className={styles.dashboardValue}>{t('bioPaywall.dashboard.cellularHealthValue')}</p>
          </div>
          <div className={styles.dashboardItem}>
            <p className={styles.dashboardLabel}>{t('bioPaywall.dashboard.recoveryRate')}</p>
            <p className={styles.dashboardValue}>{t('bioPaywall.dashboard.recoveryRateValue')}</p>
          </div>
          <div className={styles.dashboardItem}>
            <p className={styles.dashboardLabel}>{t('bioPaywall.dashboard.stressResistance')}</p>
            <p className={styles.dashboardValue}>{t('bioPaywall.dashboard.stressResistanceValue')}</p>
          </div>
          <div className={styles.dashboardItem}>
            <p className={styles.dashboardLabel}>{t('bioPaywall.dashboard.metabolicAge')}</p>
            <p className={styles.dashboardValue}>{t('bioPaywall.dashboard.metabolicAgeValue')}</p>
          </div>
        </div>
      </div>

      {/* Comparison Block */}
      <p className={styles.sectionTitle}>
        {t('bioPaywall.comparison.titleBefore')}
        <span className={styles.green}>{t('bioPaywall.comparison.titleHighlight')}</span>
      </p>
      <div className={styles.comparison}>
        <div className={styles.compLeft}>
          <p className={styles.compLabel}>{t('bioPaywall.comparison.leftTitle')}</p>
          <div className={styles.compImage} />
          <div className={styles.compPoints}>
            <div className={styles.compPointBad}>
              <span className={styles.iconBad}>✕</span>
              <span>{t('bioPaywall.comparison.leftPoint1')}</span>
            </div>
            <div className={styles.compPointBad}>
              <span className={styles.iconBad}>✕</span>
              <span>{t('bioPaywall.comparison.leftPoint2')}</span>
            </div>
          </div>
        </div>
        <div className={styles.compRight}>
          <p className={styles.compLabel}>{t('bioPaywall.comparison.rightTitle')}</p>
          <div className={styles.compImageRight} />
          <div className={styles.compPoints}>
            <div className={styles.compPointGood}>
              <span className={styles.iconGood}>✓</span>
              <span>{t('bioPaywall.comparison.rightPoint1')}</span>
            </div>
            <div className={styles.compPointGood}>
              <span className={styles.iconGood}>✓</span>
              <span>{t('bioPaywall.comparison.rightPoint2')}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <p className={styles.sectionTitle}>
        {t('bioPaywall.features.titleBefore')}
        <span className={styles.green}>{t('bioPaywall.features.titleHighlight')}</span>
      </p>
      <div className={styles.featuresList}>
        <div className={styles.featureItem}>
          <span className={styles.featureCheck}>✓</span>
          <span>{t('bioPaywall.features.item1')}</span>
        </div>
        <div className={styles.featureItem}>
          <span className={styles.featureCheck}>✓</span>
          <span>{t('bioPaywall.features.item2')}</span>
        </div>
        <div className={styles.featureItem}>
          <span className={styles.featureCheck}>✓</span>
          <span>{t('bioPaywall.features.item3')}</span>
        </div>
        <div className={styles.featureItem}>
          <span className={styles.featureCheck}>✓</span>
          <span>{t('bioPaywall.features.item4')}</span>
        </div>
        <div className={styles.featureItem}>
          <span className={styles.featureCheck}>✓</span>
          <span>{t('bioPaywall.features.item5')}</span>
        </div>
        <div className={styles.featureItem}>
          <span className={styles.featureCheck}>✓</span>
          <span>{t('bioPaywall.features.item6')}</span>
        </div>
      </div>

      {/* Reviews */}
      <p className={styles.sectionTitle}>{t('bioPaywall.reviews.title')}</p>
      <div className={styles.review}>
        <div className={styles.reviewImage1} />
        <div className={styles.reviewHeader}>
          <span className={styles.reviewName}>{t('bioPaywall.reviews.review1.name')}</span>
          <span className={styles.reviewStars}>★★★★★</span>
        </div>
        <p className={styles.reviewText}>{t('bioPaywall.reviews.review1.text')}</p>
      </div>
      <div className={styles.review}>
        <div className={styles.reviewImage2} />
        <div className={styles.reviewHeader}>
          <span className={styles.reviewName}>{t('bioPaywall.reviews.review2.name')}</span>
          <span className={styles.reviewStars}>★★★★★</span>
        </div>
        <p className={styles.reviewText}>{t('bioPaywall.reviews.review2.text')}</p>
      </div>

      {/* Plans */}
      <p className={styles.sectionTitle}>{t('bioPaywall.plans.title')}</p>
      <div
        className={`${styles.planCard} ${plan === 'trial' ? styles.planActive : ''}`}
        onClick={() => setPlan('trial')}
      >
        <div className={styles.planInfo}>
          <p className={styles.planName}>{t('bioPaywall.plans.trial.name')}</p>
          <p className={styles.planPrice}>
            {t('bioPaywall.plans.trial.priceNew')}{' '}
            <span className={styles.planOldPrice}>{t('bioPaywall.plans.trial.priceOld')}</span>
          </p>
          <p className={styles.planSub}>{t('bioPaywall.plans.trial.sub')}</p>
        </div>
        <div className={`${styles.planBadge} ${plan === 'trial' ? styles.planBadgeActive : ''}`}>
          <p className={styles.planBadgePrice}>{t('bioPaywall.plans.trial.badge')}</p>
          <p className={styles.planBadgeSub}>{t('bioPaywall.plans.trial.badgeSub')}</p>
        </div>
      </div>

      <div className={styles.planCardWrap}>
        <span className={styles.planTag}>{t('bioPaywall.plans.week.tag')}</span>
        <div
          className={`${styles.planCard} ${plan === 'week' ? styles.planActive : ''}`}
          onClick={() => setPlan('week')}
        >
          <div className={styles.planInfo}>
            <p className={styles.planName}>{t('bioPaywall.plans.week.name')}</p>
            <p className={styles.planPrice}>
              {t('bioPaywall.plans.week.priceNew')}{' '}
              <span className={styles.planOldPrice}>{t('bioPaywall.plans.week.priceOld')}</span>
            </p>
            <p className={styles.planSub}>{t('bioPaywall.plans.week.sub')}</p>
          </div>
          <div className={styles.planBadge}>
            <p className={styles.planBadgePrice}>{t('bioPaywall.plans.week.badge')}</p>
            <p className={styles.planBadgeSub}>{t('bioPaywall.plans.week.badgeSub')}</p>
          </div>
        </div>
      </div>

      <div className={styles.planCardWrap}>
        <span className={styles.planTag}>{t('bioPaywall.plans.month.tag')}</span>
        <div
          className={`${styles.planCard} ${plan === 'month' ? styles.planActive : ''}`}
          onClick={() => setPlan('month')}
        >
          <div className={styles.planInfo}>
            <p className={styles.planName}>{t('bioPaywall.plans.month.name')}</p>
            <p className={styles.planPrice}>
              {t('bioPaywall.plans.month.priceNew')}{' '}
              <span className={styles.planOldPrice}>{t('bioPaywall.plans.month.priceOld')}</span>
            </p>
            <p className={styles.planSub}>{t('bioPaywall.plans.month.sub')}</p>
          </div>
          <div className={styles.planBadge}>
            <p className={styles.planBadgePrice}>{t('bioPaywall.plans.month.badge')}</p>
            <p className={styles.planBadgeSub}>{t('bioPaywall.plans.month.badgeSub')}</p>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className={styles.ctaWrap}>
        <Button onClick={handleStart}>{t('bioPaywall.cta')}</Button>
      </div>

      {/* Legal */}
      <div className={styles.legal}>
        <p className={styles.legalLinks}>{t('bioPaywall.legal.accept')}</p>
        <p className={styles.legalText}>{t('bioPaywall.legal.terms')}</p>
      </div>
    </div>
  );
}

export default Page;
