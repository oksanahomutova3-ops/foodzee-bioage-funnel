export { default } from './BioPaywall';
