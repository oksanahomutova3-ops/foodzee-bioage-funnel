/* eslint-disable */
import React, { useState } from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './BioHeartRate.module.scss';

function Page() {
  const answer = useStore((state) => state.answer);
  const setAnswer = useStore((state) => state.setAnswer);
  const { onNext, onPrev, currentIndex } = useNav();
  const [bpm, setBpm] = useState(answer ? Number(answer) : 70);

  const handleContinue = () => {
    setAnswer(String(bpm));
    Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
      page: 'bioHeartRate',
      answer: String(bpm),
    });
    onNext();
  };

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('bioHeartRate.title')}</p>
        <p className={styles.description}>{t('bioHeartRate.subtitle')}</p>
      </div>
      <div className={styles.pickerWrap}>
        <div className={styles.picker}>
          <button className={styles.btn} onClick={() => setBpm((v) => Math.max(40, v - 1))}>−</button>
          <div className={styles.value}>
            <span className={styles.num}>{bpm}</span>
            <span className={styles.unit}>{t('bioHeartRate.unit')}</span>
          </div>
          <button className={styles.btn} onClick={() => setBpm((v) => Math.min(120, v + 1))}>+</button>
        </div>
        <input
          className={styles.slider}
          type="range"
          min={40}
          max={120}
          value={bpm}
          onChange={(e) => setBpm(Number(e.target.value))}
        />
        <div className={styles.sliderLabels}>
          <span>40</span>
          <span>120</span>
        </div>
      </div>
      <div className={styles.btnWrap}>
        <Button onClick={handleContinue}>{t('bioHeartRate.cta')}</Button>
      </div>
    </div>
  );
}

export default Page;
