export { default } from './BioHeartRate';
