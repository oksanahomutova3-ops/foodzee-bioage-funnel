/* eslint-disable */
import React from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './BioWelcome.module.scss';

function Page() {
  const { onNext, currentIndex } = useNav();

  return (
    <div className={styles.page}>
      <div className={styles.content}>
        <p className={styles.title}>{t('bioWelcome.title')}</p>
        <p className={styles.subtitle}>{t('bioWelcome.subtitle')}</p>
        <div className={styles.stats}>
          <div className={styles.stat}>
            <p className={styles.statValue}>{t('bioWelcome.stats.time')}</p>
            <p className={styles.statLabel}>{t('bioWelcome.stats.timeLabel')}</p>
          </div>
          <div className={styles.stat}>
            <p className={styles.statValue}>{t('bioWelcome.stats.users')}</p>
            <p className={styles.statLabel}>{t('bioWelcome.stats.usersLabel')}</p>
          </div>
          <div className={styles.stat}>
            <p className={styles.statValue}>{t('bioWelcome.stats.accuracy')}</p>
            <p className={styles.statLabel}>{t('bioWelcome.stats.accuracyLabel')}</p>
          </div>
        </div>
        <div className={styles.heroImage} />
      </div>
      <div className={styles.bottom}>
        <p className={styles.privacy}>{t('bioWelcome.privacy')}</p>
        <Button
          onClick={() => {
            Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', { page: 'bioWelcome' });
            onNext();
          }}
        >
          {t('bioWelcome.cta')}
        </Button>
      </div>
    </div>
  );
}

export default Page;
