export { default } from './BioWelcome';
