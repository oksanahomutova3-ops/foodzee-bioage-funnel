export { default } from './BioAge';
