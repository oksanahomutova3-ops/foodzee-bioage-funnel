/* eslint-disable */
import React, { useState } from 'react';
import { t } from '@web-solutions/module-localization';
import Analytics from '@web-solutions/module-analytics';
import { useNav } from '../../hooks/nav';
import { useStore } from '../../store/store';
import { BackIcon } from 'src/onboarding/assets/icons/BackIcon';
import Button from 'src/onboarding/components/ui/button/Button';
import styles from './BioAge.module.scss';

function Page() {
  const answer = useStore((state) => state.answer);
  const setAnswer = useStore((state) => state.setAnswer);
  const { onNext, onPrev, currentIndex } = useNav();
  const [age, setAge] = useState(answer ? Number(answer) : 30);

  const handleContinue = () => {
    setAnswer(String(age));
    Analytics.trackEvent(`step${currentIndex + 1}`, 'complete', {
      page: 'bioAge',
      answer: String(age),
    });
    onNext();
  };

  return (
    <div className={styles.page}>
      {currentIndex !== 0 && (
        <div className={styles.back} onClick={onPrev}>
          <BackIcon />
        </div>
      )}
      <div className={styles.wrapperInfo}>
        <p className={styles.title}>{t('bioAge.title')}</p>
        <p className={styles.description}>{t('bioAge.subtitle')}</p>
      </div>
      <div className={styles.pickerWrap}>
        <div className={styles.picker}>
          <button className={styles.btn} onClick={() => setAge((v) => Math.max(18, v - 1))}>−</button>
          <div className={styles.value}>
            <span className={styles.num}>{age}</span>
          </div>
          <button className={styles.btn} onClick={() => setAge((v) => Math.min(80, v + 1))}>+</button>
        </div>
        <input
          className={styles.slider}
          type="range"
          min={18}
          max={80}
          value={age}
          onChange={(e) => setAge(Number(e.target.value))}
        />
        <div className={styles.sliderLabels}>
          <span>18</span>
          <span>80</span>
        </div>
      </div>
      <div className={styles.btnWrap}>
        <Button onClick={handleContinue}>{t('bioAge.cta')}</Button>
      </div>
    </div>
  );
}

export default Page;
