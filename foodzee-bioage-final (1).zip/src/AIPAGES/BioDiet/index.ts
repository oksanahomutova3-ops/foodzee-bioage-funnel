export { default } from './BioDiet';
