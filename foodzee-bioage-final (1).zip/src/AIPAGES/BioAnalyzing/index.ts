export { default } from './BioAnalyzing';
